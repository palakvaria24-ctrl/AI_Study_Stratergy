const express = require("express");
const router = express.Router();
const StudyLog = require("../models/studyLog");
const authMiddleware = require("../middleware/authMiddleware");

// =========================
// USER ANALYTICS (FIXED)
// =========================
router.get("/", authMiddleware, async (req, res) => {
    try {

        const userId = req.user.id;

        // 🔥 GET ONLY USER DATA
        const logs = await StudyLog.find({ userId });

        const totalHours = logs.reduce((sum, log) => sum + log.hours, 0);

        const backlog = logs.length;

        const efficiency =
            totalHours > 0 ? Math.min(100, (totalHours / (backlog * 2)) * 100) : 0;

        const status =
            efficiency > 70 ? "Good" :
            efficiency > 40 ? "Average" :
            "Needs Improvement";

        res.json({
            success: true,
            data: {
                efficiency: Math.round(efficiency),
                backlog,
                status
            }
        });

    } catch (err) {
        console.error("ANALYTICS ERROR:", err);

        res.status(500).json({
            success: false,
            message: err.message
        });
    }
});

module.exports = router;