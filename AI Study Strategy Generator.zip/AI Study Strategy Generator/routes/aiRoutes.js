const express = require("express");
const router = express.Router();

const { generatePlan } = require("../controllers/aiController");

// AI PLAN GENERATION ROUTE
router.get("/generate", generatePlan);

module.exports = router;