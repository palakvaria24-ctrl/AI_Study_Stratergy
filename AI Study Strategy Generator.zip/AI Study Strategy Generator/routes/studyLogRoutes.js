const express = require("express");
const router = express.Router();

const authMiddleware = require("../middleware/authMiddleware");
const StudyLog = require("../models/studyLog");

// =========================
// ADD PLAN ROUTE
// =========================
router.post("/add", authMiddleware, async (req, res) => {

    try {

        console.log("🔥 STUDY ROUTE HIT");
        console.log("BODY:", req.body);
        console.log("USER:", req.user);

        const {
            subject,
            hours,
            actualHours,
            difficulty,
            marks,
            syllabus
        } = req.body;

        // =========================
        // VALIDATION
        // =========================
        if (!req.user || !req.user.id) {
            return res.status(401).json({
                success: false,
                message: "User not authenticated"
            });
        }

        if (!subject || !hours) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields"
            });
        }

        // =========================
        // SAVE TO MONGODB
        // =========================
        const newPlan = new StudyLog({
            userId: req.user.id,
            subject,
            hours,
            actualHours,
            difficulty,
            marks,
            syllabus
        });

        await newPlan.save();

        console.log("✅ SAVED TO MONGODB");

        res.json({
            success: true,
            message: "Study plan saved"
        });

    } catch (err) {

        console.log("❌ ERROR:", err);

        res.status(500).json({
            success: false,
            message: err.message
        });
    }
});


// =========================
// CLEAR ALL STUDY LOGS
// =========================
router.delete("/clear", authMiddleware, async (req, res) => {
    try {
        await StudyLog.deleteMany({ userId: req.user.id });

        res.json({
            success: true,
            message: "All study logs cleared"
        });

    } catch (err) {
        res.status(500).json({
            success: false,
            message: err.message
        });
    }
});

module.exports = router;