const express = require("express");
const router = express.Router();

const { addSubject, getSubjects } = require("../controllers/subjectController");
const authMiddleware = require("../middleware/authMiddleware");

// Protected Routes
router.post("/", authMiddleware, addSubject);
router.get("/", authMiddleware, getSubjects);

module.exports = router;