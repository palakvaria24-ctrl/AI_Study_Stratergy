console.log("🔥 SCRIPT.JS LOADED");

// =========================
// LOGIN
// =========================
async function loginUser() {

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const res = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (data.token) {
        localStorage.setItem("token", data.token);
        alert("Login successful");
        window.location.href = "/dashboard.html";
    } else {
        alert(data.message || "Login failed");
    }
}

// =========================
// REGISTER
// =========================
async function registerUser() {

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const res = await fetch("http://localhost:5000/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    alert(data.message || "User registered");
}

// =========================
// GLOBAL STORE
// =========================
let studyPlans = [];

// =========================
// ADD STUDY PLAN (DEBUG VERSION)
// =========================
window.addStudyPlan = async function () {

    console.log("ADD PLAN CLICKED");

    const subject = document.getElementById("subject").value;
    const hours = Number(document.getElementById("hours").value);
    const actualHours = Number(document.getElementById("actualHours").value);
    const difficulty = Number(document.getElementById("difficulty").value);
    const marks = Number(document.getElementById("marks").value);
    const syllabus = document.getElementById("syllabus").value;

    const token = localStorage.getItem("token");

    try {

        const res = await fetch("http://localhost:5000/api/study/add", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify({
                subject,
                hours,
                actualHours,
                difficulty,
                marks,
                syllabus
            })
        });

        // =========================
        // 🔥 DEBUG BLOCK (IMPORTANT)
        // =========================
        const text = await res.text();
        console.log("RAW RESPONSE:", text);

        let data;
        try {
            data = JSON.parse(text);
            console.log("PARSED RESPONSE:", data);
        } catch (e) {
            console.error("NOT JSON RESPONSE:", text);
            return;
        }

        if (!res.ok) {
            alert(data.message || "Failed to add plan");
            return;
        }

        console.log("PLAN SAVED SUCCESSFULLY");

        studyPlans.push({
            name: subject,
            score: marks,
            hours: hours,
            actualHours: actualHours,
            difficulty: difficulty,
            syllabus: syllabus
        });

        alert("Plan added successfully!");

        loadDashboard();

    } catch (err) {
        console.error("ADD PLAN ERROR:", err);
    }
};

// =========================
// DASHBOARD
// =========================
window.loadDashboard = async function () {

    console.log("LOAD DASHBOARD CALLED");

    const token = localStorage.getItem("token");

    if (!token) {
        window.location.href = "/login.html";
        return;
    }

    try {

        const res = await fetch("http://localhost:5000/api/analytics", {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        const data = await res.json();

        if (!data.data) return;

        const a = data.data;

        document.getElementById("eff").innerText = a.efficiency + "%";
        document.getElementById("backlog").innerText = a.backlog;
        document.getElementById("status").innerText = a.status;

        let totalHours = 0;
        for (let s of studyPlans) {
            totalHours += s.hours || 0;
        }

        const mlRes = await fetch("http://127.0.0.1:5001/predict", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                efficiency: a.efficiency,
                backlog: a.backlog,
                subjects: studyPlans,
                planned_hours: totalHours
            })
        });

        const m = await mlRes.json();

        console.log("ML RESPONSE:", m);

// 🔥 SAFETY FIX (VERY IMPORTANT)
        if (!m.success || !m.data) {
            document.getElementById("advice").innerText = "AI service error";
            return;
        }

        const ai = m.data;

        document.getElementById("advice").innerText =
           `Predicted Efficiency: ${ai.predictedEfficiency}%\n\n` +
           `Weak Subjects: ${ai.weakSubjects.length ? ai.weakSubjects.join(", ") : "None"}\n\n` +
           `Recommendation: ${ai.recommendation}`;
    } catch (err) {
        console.error("DASHBOARD ERROR:", err);
    }
};

// =========================
// LOAD ANALYTICS PAGE
// =========================
async function loadAnalyticsPage() {
    const token = localStorage.getItem("token");

    const res = await fetch("http://localhost:5000/api/analytics", {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });

    const data = await res.json();

    if (!data.data) return;

    document.getElementById("analyticsContent").innerHTML = `
        <h3>Efficiency: ${data.data.efficiency}%</h3>
        <h3>Backlog: ${data.data.backlog}</h3>
        <h3>Status: ${data.data.status}</h3>
    `;
}
// =========================
// LOAD INSIGHTS PAGE
// =========================
async function loadInsightsPage() {
    const token = localStorage.getItem("token");

    const res = await fetch("http://localhost:5000/api/analytics", {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });

    const data = await res.json();

    if (!data.data) return;

    const totalHours = studyPlans.reduce((sum, s) => sum + s.hours, 0);

    const mlRes = await fetch("http://127.0.0.1:5001/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            efficiency: data.data.efficiency,
            backlog: data.data.backlog,
            subjects: studyPlans,
            planned_hours: totalHours
        })
    });

    const ml = await mlRes.json();

    if (!ml.data) return;

    document.getElementById("insightsContent").innerHTML = `
        <h3>Predicted Efficiency: ${ml.data.predictedEfficiency}%</h3>
        <p><b>Weak Subjects:</b> ${ml.data.weakSubjects.join(", ") || "None"}</p>
        <p><b>Recommendation:</b> ${ml.data.recommendation}</p>
    `;
}
// =========================
// LOAD SUBJECTS PAGE
// =========================
async function loadSubjectsPage() {
    let html = "";

    studyPlans.forEach(s => {
        html += `
            <div style="margin-bottom:15px;">
                <h3>${s.name}</h3>
                <p>Marks: ${s.score}</p>
                <p>Planned Hours: ${s.hours}</p>
                <p>Actual Hours: ${s.actualHours}</p>
            </div>
        `;
    });

    document.getElementById("subjectsContent").innerHTML =
        html || "No subjects added yet.";
}

// =========================
// AUTO LOAD
// =========================
document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("eff")) loadDashboard();
    if (document.getElementById("analyticsContent")) loadAnalyticsPage();
    if (document.getElementById("insightsContent")) loadInsightsPage();
    if (document.getElementById("subjectsContent")) loadSubjectsPage();
});

// =========================
// LOGOUT
// =========================
async function logoutUser() {

    const token = localStorage.getItem("token");

    try {
        await fetch("http://localhost:5000/api/study/clear", {
            method: "DELETE",
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    } catch (err) {
        console.error("CLEAR LOG ERROR:", err);
    }

    localStorage.removeItem("token");
    window.location.href = "/login.html";
}
// =========================
// SIDEBAR NAVIGATION
// =========================

function goToDashboard() {
    window.location.href = "/dashboard.html";
}

function goToAnalytics() {
    window.location.href = "/analytics.html";
}

function goToInsights() {
    window.location.href = "/insights.html";
}

function goToSubjects() {
    window.location.href = "/subjects.html";
}

document.addEventListener("DOMContentLoaded", () => {

    console.log("DOM READY");

    const btn = document.getElementById("addPlanBtn");

    console.log("BUTTON FOUND:", btn);

    btn.addEventListener("click", () => {
        console.log("🔥 BUTTON CLICK DETECTED");
        addStudyPlan();
    });

});