import pandas as pd
from sklearn.linear_model import LinearRegression

# Sample dataset (we simulate study behavior)
data = pd.DataFrame({
    "planned_hours": [2, 3, 4, 5, 6, 7],
    "actual_hours": [1.5, 2.5, 3, 4, 4.5, 6]
})

X = data[["planned_hours"]]
y = data["actual_hours"]

model = LinearRegression()
model.fit(X, y)

def predict_efficiency(planned):
    return model.predict([[planned]])[0]