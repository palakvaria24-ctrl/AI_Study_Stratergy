import google.generativeai as genai
import os
from dotenv import load_dotenv
from flask import Flask, request, jsonify
from flask_cors import CORS
from model import predict_efficiency

# Load environment variables
load_dotenv()

# Configure Gemini
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel("gemini-1.5-flash")

# Flask app
app = Flask(__name__)
CORS(app)

# =============================
# SUBJECT INTELLIGENCE ENGINE
# =============================
def get_subject_strategy(subject):
    subject = subject.lower()

    if "signal" in subject:
        return "Focus on Fourier transforms, convolution, sampling theorem, and solve numericals daily."

    if "system" in subject:
        return "Revise Laplace transforms, system response, and practice derivations."

    if "dbms" in subject:
        return "Focus on normalization, SQL queries, transactions, indexing."

    if "micro" in subject:
        return "Study architecture, instruction sets, and embedded C programming."

    if "iot" in subject:
        return "Focus on sensors, communication protocols, and system design."

    if "image" in subject:
        return "Practice OpenCV, filters, edge detection, and transformations."

    if "communication" in subject:
        return "Revise modulation techniques, noise analysis, and signal transmission."

    return "Follow structured revision + active recall + practice questions."


# =============================
# AI SYLLABUS ANALYSIS
# =============================
def analyze_syllabus_with_ai(subject, syllabus):
    try:
        prompt = f"""
        Analyze this syllabus for the subject '{subject}'.

        Syllabus:
        {syllabus}

        Return:
        1. Difficulty level
        2. Estimated study hours required
        3. Important topics
        4. Personalized study strategy
        """

        response = model.generate_content(prompt)

        return response.text

    except Exception as e:
        return f"AI analysis failed: {str(e)}"


# =============================
# ML PREDICTION ENDPOINT
# =============================
@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.json or {}

        # -----------------------------
        # INPUT DATA
        # -----------------------------
        efficiency = data.get("efficiency", 0)
        backlog = data.get("backlog", 0)
        subjects = data.get("subjects", [])
        planned_hours = data.get("planned_hours", 0)
        actual_hours_total = 0

        # Safe type conversion
        try:
            planned_hours = float(planned_hours)
        except:
            planned_hours = 0

        # -----------------------------
        # ML CORE PREDICTION
        # -----------------------------
        predicted_actual = predict_efficiency(planned_hours)

        # -----------------------------
        # SUBJECT ANALYSIS
        # -----------------------------
        weak_subjects = []
        subject_advice = {}
        syllabus_insights = []

        for subject in subjects:
            name = subject.get("name", "Unknown")
            score = subject.get("score", 100)
            actual_hours = subject.get("actualHours", 0)
            syllabus = subject.get("syllabus", "")

            actual_hours_total += actual_hours

            if score < 60:
                weak_subjects.append(name)

            if syllabus:
                ai_analysis = analyze_syllabus_with_ai(name, syllabus)
                syllabus_insights.append(ai_analysis)

            subject_advice[name] = get_subject_strategy(name)

        # -----------------------------
        # REAL EFFICIENCY CALCULATION
        # -----------------------------
        if planned_hours > 0:
            predicted_efficiency = (actual_hours_total / planned_hours) * 100
        else:
            predicted_efficiency = 0

        # -----------------------------
        # RECOMMENDATION ENGINE
        # -----------------------------
        if predicted_efficiency > 75:
            recommendation = "Maintain consistency and revise daily"
        elif predicted_efficiency > 40:
            recommendation = "Focus on weak subjects and increase practice"
        else:
            recommendation = "Urgent: rebuild study schedule"

        # -----------------------------
        # RESPONSE (FRONTEND READY)
        # -----------------------------
        return jsonify({
            "success": True,
            "data": {
                "efficiency": round(predicted_efficiency, 2),
                "predictedEfficiency": round(predicted_efficiency, 2),
                "weakSubjects": weak_subjects,
                "subjectAdvice": subject_advice,
                "syllabusInsights": syllabus_insights,
                "recommendation": recommendation
            }
        })

    except Exception as e:
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# =============================
# HEALTH CHECK
# =============================
@app.route("/")
def home():
    return jsonify({
        "status": "AI ML Service Running",
        "message": "Study Strategy AI is active"
    })


# =============================
# RUN SERVER
# =============================
if __name__ == "__main__":
    app.run(debug=True, port=5001)