const jwt = require("jsonwebtoken");

module.exports = function (req, res, next) {

    try {

        const authHeader = req.header("Authorization");

        console.log("🔐 AUTH HEADER:", authHeader);

        if (!authHeader) {
            return res.status(401).json({
                success: false,
                message: "No token provided"
            });
        }

        // Format: "Bearer token"
        const token = authHeader.split(" ")[1];

        if (!token) {
            return res.status(401).json({
                success: false,
                message: "Invalid token format"
            });
        }

        // Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        console.log("✅ DECODED USER:", decoded);

        req.user = decoded;

        next();

    } catch (err) {

        console.log("❌ AUTH ERROR:", err.message);

        return res.status(401).json({
            success: false,
            message: "Authentication failed"
        });
    }
};