const StudyLog = require("../models/StudyLog");

// ADD STUDY PLAN
const addStudyPlan = async (req, res) => {
    try {

        const userId = req.user.id;

        const { subject, hours, difficulty } = req.body;

        const newPlan = new StudyLog({
            userId,
            subject,
            hours,
            difficulty
        });

        await newPlan.save();

        res.json({
            success: true,
            message: "Study plan added",
            data: newPlan
        });

    } catch (err) {
        res.status(500).json({
            success: false,
            message: err.message
        });
    }
};

// GET ALL PLANS
const getStudyPlans = async (req, res) => {
    try {

        const userId = req.user.id;

        const plans = await StudyLog.find({ userId });

        res.json({
            success: true,
            data: plans
        });

    } catch (err) {
        res.status(500).json({
            success: false,
            message: err.message
        });
    }
};

module.exports = {
    addStudyPlan,
    getStudyPlans
};