const Subject = require("../models/Subject");
const sendResponse = require("../utils/response");

// ADD SUBJECT
const addSubject = async (req, res) => {
    try {
        const { userId, subjectName, difficulty, examDate, totalTopics } = req.body;

        const subject = new Subject({
            userId,
            subjectName,
            difficulty,
            examDate,
            totalTopics
        });

        await subject.save();

        sendResponse(res, 201, true, "Subject added successfully", subject);

    } catch (error) {
        sendResponse(res, 500, false, error.message);
    }
};

// GET SUBJECTS
const getSubjects = async (req, res) => {
    try {
        const subjects = await Subject.find();

        sendResponse(res, 200, true, "Subjects fetched successfully", subjects);

    } catch (error) {
        sendResponse(res, 500, false, error.message);
    }
};

module.exports = { addSubject, getSubjects };