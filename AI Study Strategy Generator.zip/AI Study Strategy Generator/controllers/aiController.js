const axios = require("axios");
const Subject = require("../models/Subject");

// AI PLAN GENERATOR
const generatePlan = async (req, res) => {
    try {
        // 1. Get subjects from MongoDB
        const subjects = await Subject.find();

        if (!subjects || subjects.length === 0) {
            return res.status(400).json({
                message: "No subjects found. Add subjects first."
            });
        }

        // 2. Send to Python AI service
        const response = await axios.post(
            "http://localhost:5001/generate-plan",
            { subjects }
        );

        // 3. Return AI response
        res.json(response.data);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = { generatePlan };