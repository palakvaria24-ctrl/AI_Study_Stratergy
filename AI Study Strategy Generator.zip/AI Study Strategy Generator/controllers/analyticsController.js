const StudyLog = require("../models/StudyLog");
const axios = require("axios");

// GET ANALYTICS + ML OUTPUT
const getAnalytics = async (req, res) => {

    try {

        const userId = req.user.id;

        // 1. GET STUDY PLANS FROM MONGODB
        const plans = await StudyLog.find({ userId });

        if (!plans || plans.length === 0) {
            return res.json({
                success: true,
                data: {
                    efficiency: 0,
                    backlog: 0,
                    status: "No Data"
                }
            });
        }

        // 2. CALCULATE BASIC ANALYTICS (NODE SIDE)
        let totalHours = 0;
        let totalDifficulty = 0;

        plans.forEach(p => {
            totalHours += p.hours;
            totalDifficulty += p.difficulty;
        });

        const efficiency = Math.min(100, (totalHours / (plans.length * 5)) * 20);
        const backlog = plans.filter(p => p.hours > 5).length;

        let status = "Good";
        if (efficiency < 40) status = "Weak";
        if (efficiency > 75) status = "Strong";
        console.log("ML INPUT DATA:", {
            efficiency,
            backlog,
            subjects: plans
        });
        // 3. CALL PYTHON ML MODEL
        const mlResponse = await axios.post("http://127.0.0.1:5001/predict", {
            efficiency,
            backlog,
            subjects: plans.map(p => ({
                name: p.subject,
                score: 100 - (p.difficulty * 10)
            }))
        });

        const mlData = mlResponse.data;

        // 4. SEND FINAL RESPONSE
        res.json({
            success: true,
            data: {
                efficiency,
                backlog,
                status,
                ml: mlData,
                plans
            }
        });

    } catch (err) {
        res.status(500).json({
            success: false,
            message: err.message
        });
    }
};

module.exports = { getAnalytics };