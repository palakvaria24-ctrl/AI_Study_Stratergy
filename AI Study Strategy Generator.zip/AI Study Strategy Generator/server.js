const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config();

const app = express();

// =========================
// MIDDLEWARE
// =========================
app.use(cors());
app.use(express.json());

// =========================
// DATABASE CONNECTION
// =========================
mongoose.connect(process.env.MONGO_URI)
.then(() => console.log("🔥 MongoDB Connected"))
.catch(err => console.error("MongoDB Error:", err));

// =========================
// ROUTES IMPORT
// =========================
const authRoutes = require("./routes/authRoutes");
const studyRoutes = require("./routes/studyLogRoutes");
const analyticsRoutes = require("./routes/analyticsRoutes");

// =========================
// API ROUTES
// =========================
app.use("/api/auth", authRoutes);
app.use("/api/study", studyRoutes);
app.use("/api/analytics", analyticsRoutes);

// =========================
// FRONTEND STATIC FILES
// =========================
app.use(express.static(path.join(__dirname, "frontend")));

// =========================
// DEFAULT ROUTES (PAGES)
// =========================
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "frontend", "login.html"));
});

app.get("/dashboard.html", (req, res) => {
    res.sendFile(path.join(__dirname, "frontend", "dashboard.html"));
});
app.get("/analytics.html", (req, res) => {
    res.sendFile(path.join(__dirname, "frontend", "analytics.html"));
});

app.get("/insights.html", (req, res) => {
    res.sendFile(path.join(__dirname, "frontend", "insights.html"));
});

app.get("/subjects.html", (req, res) => {
    res.sendFile(path.join(__dirname, "frontend", "subjects.html"));
});
app.get("/login.html", (req, res) => {
    res.sendFile(path.join(__dirname, "frontend", "login.html"));
});

// =========================
// HEALTH CHECK
// =========================
app.get("/health", (req, res) => {
    res.json({
        status: "OK",
        message: "Server is running"
    });
});

// =========================
// START SERVER
// =========================
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`🚀 SERVER RUNNING ON http://localhost:${PORT}`);
});