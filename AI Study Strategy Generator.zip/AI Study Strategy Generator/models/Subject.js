const mongoose = require("mongoose");

const SubjectSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    subjectName: {
        type: String,
        required: true
    },
    difficulty: {
        type: Number,
        required: true
    },
    examDate: {
        type: Date,
        required: true
    },
    totalTopics: {
        type: Number,
        required: true
    }
});

module.exports = mongoose.model("Subject", SubjectSchema);