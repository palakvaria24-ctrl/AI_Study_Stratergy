const mongoose = require("mongoose");

const studyLogSchema = new mongoose.Schema({

    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
    },

    subject: {
        type: String,
        required: true
    },

    hours: {
        type: Number,
        required: true
    },

    difficulty: {
    type: Number,
    required: true
    },

    actualHours: {
    type: Number,
    default: 0
    },

    marks: {
    type: Number,
    default: 0
    },

    syllabus: {
    type: String,
    default: ""
    },

    createdAt: {
        type: Date,
        default: Date.now
    }

});

module.exports = mongoose.model("StudyLog", studyLogSchema);